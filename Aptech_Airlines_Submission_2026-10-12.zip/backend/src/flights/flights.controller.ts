import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
  UseGuards,
} from '@nestjs/common';
import { FlightsService } from './flights.service';
import { FlightGeneratorService } from './flight-generator.service';
import { AirlabsCommercialService } from './airlabs-commercial.service';
import {
  CreateFlightDto,
  SearchFlightDto,
  UpdateFlightDto,
  UpdateFlightStatusDto,
  CommercializeRouteDto,
  UpdateCommercialTemplateDto,
  MaterializeTemplateDto,
  isValidCalendarDateString,
} from './flights.dto';
import { CommercialNetworkDiscoveryDto } from './airlabs-commercial.dto';
import { FlightStatus } from './flights.schema';
import { JwtAuthGuard } from '../auth/auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { UserRole } from '../users/users.schema';
import { RevenuePricingService } from './revenue-pricing.service';
import {
  AssignPricingProfileDto,
  CreatePricingProfileDto,
  UpdatePricingProfileDto,
} from './pricing-profile.dto';

// Admin roles allowed to mutate flight data (create/update/delete/status) and trigger AirLabs enrichment
const ADMIN_ROLES = [UserRole.ADMIN, UserRole.SUPER_ADMIN];

// NOTE: every @Get route below stays public on purpose (requirements 3.3 & 3.10:
// guests must be able to search, lookup and view flights/seat maps without auth).
@Controller('flights')
export class FlightsController {
  constructor(
    private readonly flightsService: FlightsService,
    private readonly flightGeneratorService?: FlightGeneratorService,
    private readonly airlabsCommercialService?: AirlabsCommercialService,
    private readonly revenuePricingService?: RevenuePricingService,
  ) {}

  @Get('search')
  async search(@Query() searchDto: SearchFlightDto) {
    return this.flightsService.searchFlights(searchDto);
  }

  // Requirement 3.3.3 & Phase A: Bounded nearby-date availability lookup
  @Get('nearby-availability')
  async getNearbyAvailability(
    @Query('origin') origin: string,
    @Query('destination') destination: string,
    @Query('date') date: string,
    @Query('cabin_class') cabinClass?: any,
    @Query('passengers') passengers?: number,
    @Query('adults') adults?: number,
    @Query('children') children?: number,
    @Query('seniors') seniors?: number,
  ) {
    if (!origin || !destination || !date) {
      throw new BadRequestException('origin, destination, and date query parameters are required');
    }
    return this.flightsService.getNearbyAvailability(
      origin,
      destination,
      date,
      cabinClass,
      passengers ? Number(passengers) : 1,
      adults ? Number(adults) : 1,
      children ? Number(children) : 0,
      seniors ? Number(seniors) : 0,
    );
  }

  private validateScheduleGenerationInput(
    startDate?: string,
    days?: any,
  ): { parsedStartDate?: string; parsedDays: number } {
    let parsedDays = 330;
    if (days !== undefined && days !== null && days !== '') {
      const num = typeof days === 'number' ? days : Number(days);
      if (typeof days === 'string' && days.trim() === '') {
        parsedDays = 330;
      } else if (isNaN(num) || !Number.isInteger(num)) {
        throw new BadRequestException('days must be an integer');
      } else if (num < 1 || num > 330) {
        throw new BadRequestException('days must be between 1 and 330');
      } else {
        parsedDays = num;
      }
    }

    if (startDate !== undefined && startDate !== null && startDate !== '') {
      if (!isValidCalendarDateString(startDate)) {
        throw new BadRequestException('start_date must be a valid calendar date in YYYY-MM-DD format');
      }
    }

    return { parsedStartDate: startDate || undefined, parsedDays };
  }

  // Admin on-demand schedule generation (default: AirLabs commercial templates)
  @Post('generate-schedule')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async generateSchedule(
    @Query('start_date') startDate?: string,
    @Query('days') days?: any,
  ) {
    if (!this.flightGeneratorService) {
      throw new BadRequestException('FlightGeneratorService not available');
    }
    const { parsedStartDate, parsedDays } = this.validateScheduleGenerationInput(startDate, days);
    return this.flightGeneratorService.generateActiveCommercialTemplates(parsedStartDate, parsedDays);
  }

  // Explicit legacy synthetic generation (kept for compatibility and regression tests)
  @Post('generate-legacy-schedule')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async generateLegacySchedule(
    @Query('start_date') startDate?: string,
    @Query('days') days?: any,
  ) {
    if (!this.flightGeneratorService) {
      throw new BadRequestException('FlightGeneratorService not available');
    }
    const { parsedStartDate, parsedDays } = this.validateScheduleGenerationInput(startDate, days);
    return this.flightGeneratorService.generateRollingSchedule(parsedStartDate, parsedDays);
  }

  @Get()
  async findAll(
    @Query('status') status?: FlightStatus,
    @Query('origin') origin?: string,
    @Query('dest') dest?: string,
    @Query('commercial_only') commercialOnly?: string,
  ) {
    const isCommercialOnly = commercialOnly === 'true';
    return this.flightsService.findAll(status, origin, dest, isCommercialOnly);
  }

  // Requirement 3.10: public lookup by flight number + date (must be above @Get(':id'))
  @Get('lookup')
  async lookup(
    @Query('flight_number') flightNumber?: string,
    @Query('date') date?: string,
  ) {
    if (!flightNumber || !date) {
      throw new BadRequestException('flight_number and date query params are required');
    }
    return this.flightsService.findByFlightNumberAndDate(flightNumber, date);
  }

  @Get('airline-fleet')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async getAirlineFleet(@Query('airline_iata') airlineIata: string) {
    if (!airlineIata) {
      throw new BadRequestException('airline_iata query param is required');
    }
    return this.flightsService.getAirlineFleet(airlineIata);
  }

  @Post('enrich-airborne')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async enrichAirborneFlightsForToday() {
    return this.flightsService.enrichAirborneFlightsForToday();
  }

  @Get('booking-window')
  async getBookingWindow() {
    const { getBookingWindowLimits } = await import('../common/pricing.util');
    return getBookingWindowLimits();
  }

  @Get('pricing-profiles')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async listPricingProfiles() {
    if (!this.revenuePricingService) throw new BadRequestException('RevenuePricingService is not available');
    return this.revenuePricingService.listProfiles();
  }

  @Post('pricing-profiles')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async createPricingProfile(@Body() dto: CreatePricingProfileDto) {
    if (!this.revenuePricingService) throw new BadRequestException('RevenuePricingService is not available');
    return this.revenuePricingService.createProfile(dto);
  }

  @Patch('pricing-profiles/:id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async updatePricingProfile(@Param('id') id: string, @Body() dto: UpdatePricingProfileDto) {
    if (!this.revenuePricingService) throw new BadRequestException('RevenuePricingService is not available');
    return this.revenuePricingService.updateProfile(id, dto);
  }

  @Post('pricing-profiles/:id/assign')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async assignPricingProfile(@Param('id') id: string, @Body() dto: AssignPricingProfileDto) {
    if (!this.revenuePricingService) throw new BadRequestException('RevenuePricingService is not available');
    return this.revenuePricingService.assignProfile(id, dto);
  }

  @Delete('pricing-profiles/:id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async deletePricingProfile(@Param('id') id: string) {
    if (!this.revenuePricingService) throw new BadRequestException('RevenuePricingService is not available');
    return this.revenuePricingService.deleteProfile(id);
  }

  // --- Phase C1: AirLabs-Backed Commercial Flight Endpoints (Admin) ---

  @Get('airlabs-routes')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async listAirlabsRoutes(
    @Query('dep_iata') depIata?: string,
    @Query('arr_iata') arrIata?: string,
    @Query('has_schedule') hasSchedule?: string,
    @Query('limit') limit?: number,
    @Query('offset') offset?: number,
  ) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.listAirlabsRoutesWithSchedule({
      dep_iata: depIata,
      arr_iata: arrIata,
      has_schedule: hasSchedule !== undefined ? hasSchedule === 'true' : true,
      limit: limit ? Number(limit) : 50,
      offset: offset ? Number(offset) : 0,
    });
  }

  @Get('airlabs-routes/:sourceKey')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async getAirlabsRouteDetail(@Param('sourceKey') sourceKey: string) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.getAirlabsRouteDetail(sourceKey);
  }

  @Post('commercialize-airlabs-route')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async commercializeAirlabsRoute(@Body() dto: CommercializeRouteDto) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.commercializeRoute(dto);
  }

  @Get('commercial-templates')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async listCommercialTemplates(
    @Query('source_type') sourceType?: string,
    @Query('is_active') isActive?: string,
    @Query('origin_iata') originIata?: string,
    @Query('dest_iata') destIata?: string,
    @Query('limit') limit?: number,
    @Query('offset') offset?: number,
  ) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.listCommercialTemplates({
      source_type: sourceType,
      is_active: isActive !== undefined ? isActive === 'true' : undefined,
      origin_iata: originIata,
      dest_iata: destIata,
      limit: limit ? Number(limit) : 50,
      offset: offset ? Number(offset) : 0,
    });
  }

  @Patch('commercial-templates/:id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async updateCommercialTemplate(
    @Param('id') id: string,
    @Body() dto: UpdateCommercialTemplateDto,
  ) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.updateCommercialTemplate(id, dto);
  }

  @Patch('commercial-templates/:id/status')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async setCommercialTemplateStatus(
    @Param('id') id: string,
    @Body('is_active') isActive: boolean,
  ) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.setTemplateStatus(id, isActive);
  }

  @Post('commercial-templates/:id/materialize')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async materializeCommercialTemplate(
    @Param('id') id: string,
    @Body() body: MaterializeTemplateDto,
  ) {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.materializeTemplate(
      id,
      body?.days_ahead || 30,
      body?.start_date,
    );
  }

  @Get('commercial-aircraft-layouts')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async getCommercialAircraftLayouts() {
    if (!this.airlabsCommercialService) {
      throw new BadRequestException('AirlabsCommercialService is not available');
    }
    return this.airlabsCommercialService.getCommercialAircraftLayouts();
  }

  @Post('commercial-network-discovery')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async discoverCommercialNetwork(@Body() dto: CommercialNetworkDiscoveryDto) {
    return this.flightsService.discoverCommercialNetwork(dto);
  }

  @Get(':id')
  async findOne(@Param('id') id: string) {
    return this.flightsService.findById(id);
  }

  @Post(':id/enrich-aircraft')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async enrichAircraftFromAirLabs(@Param('id') id: string) {
    return this.flightsService.enrichAircraftFromAirLabs(id);
  }

  @Get(':id/seat-map')
  async getSeatMap(@Param('id') id: string) {
    return this.flightsService.getSeatMap(id);
  }

  @Post('sync-airlabs')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN, UserRole.SUPER_ADMIN)
  async syncAirLabs(
    @Query('mode') mode?: string,
    @Query('dep_iata') depIata?: string,
    @Query('arr_iata') arrIata?: string,
    @Query('airline_iata') airlineIata?: string,
    @Query('flight_iata') flightIata?: string,
    // limit max: 1000 for airport, 200 for airline. Note: Free keys cap at 50.
    @Query('limit') limit?: number,
    @Query('offset') offset?: number,
    @Query('api_key') apiKey?: string,
    @Body('api_key') bodyApiKey?: string,
  ) {
    return this.flightsService.syncFromAirLabs(
      mode,
      depIata,
      arrIata,
      airlineIata,
      flightIata,
      limit ? parseInt(limit.toString(), 10) : 50,
      offset ? parseInt(offset.toString(), 10) : 0,
      apiKey || bodyApiKey,
    );
  }

  @Post()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async create(@Body() createFlightDto: CreateFlightDto) {
    return this.flightsService.create(createFlightDto);
  }

  @Put(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async update(
    @Param('id') id: string,
    @Body() updateFlightDto: UpdateFlightDto,
  ) {
    return this.flightsService.update(id, updateFlightDto);
  }

  @Patch(':id/status')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async updateStatus(
    @Param('id') id: string,
    @Body() dto: UpdateFlightStatusDto,
  ) {
    return this.flightsService.updateStatus(id, dto);
  }

  @Delete(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(...ADMIN_ROLES)
  async delete(@Param('id') id: string) {
    return this.flightsService.deleteFlight(id);
  }
}
